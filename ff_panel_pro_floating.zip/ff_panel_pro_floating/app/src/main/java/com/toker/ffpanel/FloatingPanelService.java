package com.toker.ffpanel;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingPanelService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14,10,14,10);
        box.setBackgroundColor(Color.rgb(18,8,38));

        TextView head = label("FF PANEL PRO   [×]", 16, Color.rgb(218,150,255));
        box.addView(head);
        head.setOnClickListener(v -> stopSelf());

        TextView status = label("MOBILE OVERLAY  •  VISUAL TOOLS", 10, Color.LTGRAY);
        box.addView(status);

        TextView cross = label("+", 30, Color.CYAN);
        cross.setGravity(Gravity.CENTER);
        box.addView(cross);

        TextView note = label("Crosshair: ON", 12, Color.WHITE);
        box.addView(note);
        note.setOnClickListener(v -> {
            boolean shown = cross.getVisibility() == View.VISIBLE;
            cross.setVisibility(shown ? View.GONE : View.VISIBLE);
            note.setText(shown ? "Crosshair: OFF" : "Crosshair: ON");
        });

        TextView close = label("TUTUP PANEL", 12, Color.rgb(204,150,255));
        box.addView(close);
        close.setOnClickListener(v -> stopSelf());

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 18; params.y = 180;

        head.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY; float downX, downY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX=params.x; startY=params.y; downX=e.getRawX(); downY=e.getRawY(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x=startX+(int)(e.getRawX()-downX);
                    params.y=startY+(int)(e.getRawY()-downY);
                    wm.updateViewLayout(panel, params); return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });
        panel = box;
        wm.addView(panel, params);
    }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(8,7,8,7);
        return t;
    }

    @Override public void onDestroy() {
        if (wm != null && panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
