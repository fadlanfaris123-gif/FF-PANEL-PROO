package com.toker.ffpanel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,6,17));
        getWindow().setNavigationBarColor(Color.rgb(8,6,17));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7,6,17));
        TextView title = new TextView(this);
        title.setText("FF PANEL PRO  •  MOBILE");
        title.setTextColor(Color.rgb(207,126,255));
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        title.setPadding(12,20,12,12);
        root.addView(title);
        Button overlay = new Button(this);
        overlay.setText("AKTIFKAN PANEL MENGAMBANG");
        root.addView(overlay);
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, FloatingPanelService.class));
            }
        });
        TextView info = new TextView(this);
        info.setText("Panel mengambang berisi crosshair visual dan kontrol latihan. Tidak mengunci target atau mengubah bidikan Free Fire.");
        info.setTextColor(Color.LTGRAY);
        info.setPadding(16,10,16,10);
        root.addView(info);
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(7,6,17));
        web.setWebViewClient(new WebViewClient());
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(true);
        web.loadUrl("file:///android_asset/index.html");
        root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    @Override protected void onResume() {
        super.onResume();
        if (Settings.canDrawOverlays(this)) {
            // User can activate the floating panel with the button.
        }
    }
}
