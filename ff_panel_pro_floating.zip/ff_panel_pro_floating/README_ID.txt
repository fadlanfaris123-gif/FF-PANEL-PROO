FF PANEL PRO - Proyek Android pendamping

Build APK via GitHub Actions:
1. Buat repository GitHub baru.
2. Unggah SELURUH ISI folder proyek ini ke root repository (termasuk folder .github).
3. Buka tab Actions dan pilih workflow "Build Android APK".
4. Tekan Run workflow, lalu tunggu sampai selesai.
5. Pada run yang sukses, unduh artifact "ff-panel-pro-debug-apk".
6. Ekstrak artifact ZIP untuk mendapatkan app-debug.apk.

Catatan: Ini APK debug untuk panel pendamping, crosshair/visual dan aim trainer.
Tidak menyediakan auto-headshot/aim-lock yang memanipulasi Free Fire. File APK belum
terkompilasi di paket ini; GitHub Actions yang akan melakukan build.
